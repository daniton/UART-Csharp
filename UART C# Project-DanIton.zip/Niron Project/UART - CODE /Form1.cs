﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace UART
{
    
    public partial class Form1 : Form
    {
        string dataIN,Out;
        string [] dataInlist;
        int i = 1;
        public Form1()
        {
            InitializeComponent();
        }
     
      
        private void OpenUart_Click(object sender, EventArgs e)
        {
            try
            {
                if (CBOondD.Checked)
                {
                    //Option 1: Only one Device:
                    //Serial Port 1 : Sender side.
                    serialPort1.PortName = COBport.Text;
                    serialPort1.BaudRate = Convert.ToInt32(COBbaud.Text);
                    serialPort1.DataBits = Convert.ToInt32(CobDbits.Text);
                    serialPort1.StopBits = (StopBits)Enum.Parse(typeof(StopBits), CobSbits.Text);
                    serialPort1.Parity = (Parity)Enum.Parse(typeof(Parity), CobPbits.Text);
                    serialPort1.Open();

                    //Serial Port 2 : Receiver Side.
                    serialPort2.PortName = COBportR.Text;
                    serialPort2.BaudRate = serialPort1.BaudRate;
                    serialPort2.DataBits = serialPort1.DataBits;
                    serialPort2.StopBits = serialPort1.StopBits;
                    serialPort2.Parity = serialPort1.Parity;
                    serialPort2.Open();
                    COBportR.Enabled = true;
                }
                else if (CBOtwoD.Checked)
                {
                    //Option 2: Two Devices:
                    //Serial Port 1 : Sender side.
                    serialPort1.PortName = COBport.Text;
                    serialPort1.BaudRate = Convert.ToInt32(COBbaud.Text);
                    serialPort1.DataBits = Convert.ToInt32(CobDbits.Text);
                    serialPort1.StopBits = (StopBits)Enum.Parse(typeof(StopBits), CobSbits.Text);
                    serialPort1.Parity = (Parity)Enum.Parse(typeof(Parity), CobPbits.Text);
                    serialPort1.Open();

                }
                else
                    throw new Exception();
                progressBar1.Value = 100;
                btnClear.Enabled = true;
                SendUart.Enabled = true;
                openUart.Enabled = false; //Prevent user to select Open when a com port already in use.
                CloseUart.Enabled = true;
                CBOondD.Enabled = false;
                CBOtwoD.Enabled = false;
                CharBox.Checked = true; //default
            }
            //When Error/Warnning:
            catch(Exception ex)
            {
                if (COBport.Text == "NONE")//When no Port Chosen;
                {
                    MessageBox.Show("Please Choose Port!", "Warrning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                if(CBOondD.Checked == false & CBOtwoD.Checked==false)//When none of the options checked.
                    MessageBox.Show("Please Mark the Devices Option!", "Warrning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                openUart.Enabled = true;
                CloseUart.Enabled = false;
                SendUart.Enabled = false;
                serialPort2.Close();
                serialPort1.Close();
                progressBar1.Value = 0;
            }
        }

        private void CloseUart_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.Close();
                serialPort2.Close();
                progressBar1.Value = 0;
                openUart.Enabled = true;
                CloseUart.Enabled = false;
                btnClear.Enabled = false;
                SendUart.Enabled = false;
                CBOondD.Enabled = true;
                CBOtwoD.Enabled = true;
                CBOondD.Checked = false;
                CBOtwoD.Checked = false;
                CharBox.Enabled = false;
                HexBox.Enabled = false;
                i = 1;
                ReceiveTxt.Clear();
                
            }
            //When Error:
            catch (Exception ex)
            {
             MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
             btnClear.Enabled = true;
                SendUart.Enabled = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            openUart.Enabled = true;
            CloseUart.Enabled = false;
            btnClear.Enabled = false;
            SendUart.Enabled = false;
            COBportR.Enabled = false;
            CBOondD.Enabled = true;
            CBOtwoD.Enabled = true;
            CharBox.Enabled = false;
            HexBox.Enabled = false;
            //Getting Port Names frome Computer.
            string[] ports = SerialPort.GetPortNames();
            COBport.Items.AddRange(ports);//add array of Ports to the list of items.
            COBportR.Items.AddRange(ports);//add array of Ports to the list of items.
        }

      


        private void SendUart_Click_1(object sender, EventArgs e)
        {
            {
                try
                {
                    if (serialPort1.IsOpen & (CharBox.Checked || HexBox.Checked))
                    {

                        serialPort1.Write(SendTxt.Text); //+Environment.NewLine);
                        SendTxt.Clear();
                    }
                    else
                        throw new Exception();
                }
                //When Error/Warnning:
                catch (Exception ex)
                {
                    if (HexBox.Checked == false & CharBox.Checked == false)//When none of the options checked.
                        MessageBox.Show("Please Mark the Format Option!", "Warrning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    else 
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort1.IsOpen)
                serialPort1.Close();
            if (serialPort2.IsOpen)
                serialPort2.Close();
           
        }


        private void Clear_Click_1(object sender, EventArgs e)
        {
            if(ReceiveTxt.Text != "")
            {
                ReceiveTxt.Clear();
            }
        }

        //When Using Other Sender Terminal ( Tera Term, Putty ....)

       

        private void ShowData(object sender, EventArgs e)
        {
            //dataIN = RxDataFormat(dataInDec);
            try
            {
                if (CBOondD.Checked)
                {
                    ReceiveTxt.Text = ReceiveTxt.Text + $"Trasmission Number: {i} " + Environment.NewLine + dataIN + Environment.NewLine;
                    i += 1;
                }
                else if (CBOtwoD.Checked)
                {
                    ReceiveTxt.Text = ReceiveTxt.Text + Out; //$"Trasmission Number: {i} " + Environment.NewLine + Out + Environment.NewLine;
                    i += 1;
                }


            }
            //When Error/Warnning:
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                i = 1;
                
            }

        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {

            Out = RxDataFormat(serialPort1.ReadExisting());
            this.Invoke(new EventHandler(ShowData));


        }

        private void CBOondD_CheckedChanged(object sender, EventArgs e)
        {
            if (CBOondD.Checked)
            {
                COBportR.Enabled = true;
                CharBox.Enabled = true;
                HexBox.Enabled = true;
                CBOtwoD.Checked = false;
            }
            else
            {
                CharBox.Enabled = false;
                HexBox.Enabled = false;
            }
            
        }

        private void CBOtwoD_CheckedChanged(object sender, EventArgs e)
        {
            if (CBOtwoD.Checked)
            {
                COBportR.Enabled = false;
                CBOondD.Checked = false;
                CharBox.Enabled = false;//no need
                HexBox.Enabled = false;//no need 
            }
        }

        private void serialPort2_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            dataIN  = RxDataFormat(serialPort2.ReadExisting());
            this.Invoke(new EventHandler(ShowData));
        }

        private void HexBox_CheckedChanged(object sender, EventArgs e)
        {
            if (HexBox.Checked)
            {
                CharBox.Checked = false;
            }
        }

        private void CharBox_CheckedChanged(object sender, EventArgs e)
        {
            if (CharBox.Checked)
            {
                HexBox.Checked = false;
            }
        }

        private string RxDataFormat(string dataInput)
        {
            string strOut = ""; 
            //suite for simulation using only one device you can choose the format you want to send the data.
            if (HexBox.Checked)
            {
                dataInlist = dataInput.Split('-','\n');
                foreach (string hex in dataInlist)
                {
                    // Convert the number expressed in base-16 to an integer.
                    try
                    {
                        int value = Convert.ToInt32(hex, 16);
                        // Get the character corresponding to the integral value.
                        strOut = strOut + Char.ConvertFromUtf32(value);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }
            }
            //Suite For microcontroller devices or FPGAs that sends data in hexadecimal .
            else if (CharBox.Checked)
            {
                strOut = dataInput + "\n";
            }

            return strOut;
        }
    }
}

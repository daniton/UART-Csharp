﻿namespace UART
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.openUart = new System.Windows.Forms.Button();
            this.CloseUart = new System.Windows.Forms.Button();
            this.COM = new System.Windows.Forms.Label();
            this.COBport = new System.Windows.Forms.ComboBox();
            this.SendTxt = new System.Windows.Forms.TextBox();
            this.ReceiveTxt = new System.Windows.Forms.TextBox();
            this.SendUart = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.COBbaud = new System.Windows.Forms.ComboBox();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.Dbits = new System.Windows.Forms.Label();
            this.CobDbits = new System.Windows.Forms.ComboBox();
            this.CobSbits = new System.Windows.Forms.ComboBox();
            this.Sbits = new System.Windows.Forms.Label();
            this.Pbits = new System.Windows.Forms.Label();
            this.CobPbits = new System.Windows.Forms.ComboBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.serialPort2 = new System.IO.Ports.SerialPort(this.components);
            this.COBportR = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.CBOondD = new System.Windows.Forms.CheckBox();
            this.CBOtwoD = new System.Windows.Forms.CheckBox();
            this.HexBox = new System.Windows.Forms.CheckBox();
            this.CharBox = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // openUart
            // 
            this.openUart.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.openUart.Font = new System.Drawing.Font("Arial Nova Cond", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.openUart.Location = new System.Drawing.Point(320, 32);
            this.openUart.Name = "openUart";
            this.openUart.Size = new System.Drawing.Size(75, 49);
            this.openUart.TabIndex = 0;
            this.openUart.Text = "OPEN";
            this.openUart.UseVisualStyleBackColor = false;
            this.openUart.Click += new System.EventHandler(this.OpenUart_Click);
            // 
            // CloseUart
            // 
            this.CloseUart.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CloseUart.Font = new System.Drawing.Font("Arial Nova Cond", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CloseUart.Location = new System.Drawing.Point(434, 32);
            this.CloseUart.Name = "CloseUart";
            this.CloseUart.Size = new System.Drawing.Size(75, 49);
            this.CloseUart.TabIndex = 1;
            this.CloseUart.Text = "CLOSE";
            this.CloseUart.UseVisualStyleBackColor = false;
            this.CloseUart.Click += new System.EventHandler(this.CloseUart_Click);
            // 
            // COM
            // 
            this.COM.AutoSize = true;
            this.COM.Font = new System.Drawing.Font("Arial Nova Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.COM.Location = new System.Drawing.Point(12, 45);
            this.COM.Name = "COM";
            this.COM.Size = new System.Drawing.Size(81, 20);
            this.COM.TabIndex = 2;
            this.COM.Text = "COM PORT";
            // 
            // COBport
            // 
            this.COBport.FormattingEnabled = true;
            this.COBport.Location = new System.Drawing.Point(108, 44);
            this.COBport.Name = "COBport";
            this.COBport.Size = new System.Drawing.Size(121, 21);
            this.COBport.TabIndex = 3;
            this.COBport.Text = "NONE";
            // 
            // SendTxt
            // 
            this.SendTxt.Location = new System.Drawing.Point(349, 147);
            this.SendTxt.Multiline = true;
            this.SendTxt.Name = "SendTxt";
            this.SendTxt.Size = new System.Drawing.Size(328, 115);
            this.SendTxt.TabIndex = 4;
            // 
            // ReceiveTxt
            // 
            this.ReceiveTxt.Location = new System.Drawing.Point(349, 294);
            this.ReceiveTxt.Multiline = true;
            this.ReceiveTxt.Name = "ReceiveTxt";
            this.ReceiveTxt.Size = new System.Drawing.Size(329, 115);
            this.ReceiveTxt.TabIndex = 6;
            // 
            // SendUart
            // 
            this.SendUart.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.SendUart.Font = new System.Drawing.Font("Arial Nova Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SendUart.Location = new System.Drawing.Point(684, 182);
            this.SendUart.Name = "SendUart";
            this.SendUart.Size = new System.Drawing.Size(75, 28);
            this.SendUart.TabIndex = 8;
            this.SendUart.Text = "SEND";
            this.SendUart.UseVisualStyleBackColor = false;
            this.SendUart.Click += new System.EventHandler(this.SendUart_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Nova Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Baudrate";
            // 
            // COBbaud
            // 
            this.COBbaud.FormattingEnabled = true;
            this.COBbaud.Items.AddRange(new object[] {
            "2400",
            "4800",
            "9600",
            "115200"});
            this.COBbaud.Location = new System.Drawing.Point(108, 118);
            this.COBbaud.Name = "COBbaud";
            this.COBbaud.Size = new System.Drawing.Size(121, 21);
            this.COBbaud.TabIndex = 10;
            this.COBbaud.Text = "9600";
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(320, 87);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(189, 23);
            this.progressBar1.TabIndex = 11;
            // 
            // Dbits
            // 
            this.Dbits.AutoSize = true;
            this.Dbits.Font = new System.Drawing.Font("Arial Nova Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dbits.Location = new System.Drawing.Point(12, 154);
            this.Dbits.Name = "Dbits";
            this.Dbits.Size = new System.Drawing.Size(77, 20);
            this.Dbits.TabIndex = 12;
            this.Dbits.Text = "DATA BITS";
            // 
            // CobDbits
            // 
            this.CobDbits.FormattingEnabled = true;
            this.CobDbits.Items.AddRange(new object[] {
            "5",
            "6",
            "7",
            "8"});
            this.CobDbits.Location = new System.Drawing.Point(108, 153);
            this.CobDbits.Name = "CobDbits";
            this.CobDbits.Size = new System.Drawing.Size(121, 21);
            this.CobDbits.TabIndex = 13;
            this.CobDbits.Text = "8";
            // 
            // CobSbits
            // 
            this.CobSbits.FormattingEnabled = true;
            this.CobSbits.Items.AddRange(new object[] {
            "One",
            "Two"});
            this.CobSbits.Location = new System.Drawing.Point(108, 189);
            this.CobSbits.Name = "CobSbits";
            this.CobSbits.Size = new System.Drawing.Size(121, 21);
            this.CobSbits.TabIndex = 15;
            this.CobSbits.Text = "One";
            // 
            // Sbits
            // 
            this.Sbits.AutoSize = true;
            this.Sbits.Font = new System.Drawing.Font("Arial Nova Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sbits.Location = new System.Drawing.Point(12, 187);
            this.Sbits.Name = "Sbits";
            this.Sbits.Size = new System.Drawing.Size(78, 20);
            this.Sbits.TabIndex = 14;
            this.Sbits.Text = "STOP BITS";
            // 
            // Pbits
            // 
            this.Pbits.AutoSize = true;
            this.Pbits.Font = new System.Drawing.Font("Arial Nova Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pbits.Location = new System.Drawing.Point(12, 228);
            this.Pbits.Name = "Pbits";
            this.Pbits.Size = new System.Drawing.Size(90, 20);
            this.Pbits.TabIndex = 16;
            this.Pbits.Text = "PARITY BITS";
            // 
            // CobPbits
            // 
            this.CobPbits.FormattingEnabled = true;
            this.CobPbits.Items.AddRange(new object[] {
            "Odd",
            "Even"});
            this.CobPbits.Location = new System.Drawing.Point(108, 227);
            this.CobPbits.Name = "CobPbits";
            this.CobPbits.Size = new System.Drawing.Size(121, 21);
            this.CobPbits.TabIndex = 17;
            this.CobPbits.Text = "None";
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnClear.Font = new System.Drawing.Font("Arial Nova Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(444, 415);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(144, 32);
            this.btnClear.TabIndex = 18;
            this.btnClear.Text = "Clear Data Buffer";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.Clear_Click_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Nova Cond", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(345, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 26);
            this.label2.TabIndex = 19;
            this.label2.Text = "TX";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Nova Cond", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(344, 265);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 26);
            this.label3.TabIndex = 20;
            this.label3.Text = "RX";
            // 
            // serialPort2
            // 
            this.serialPort2.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort2_DataReceived);
            // 
            // COBportR
            // 
            this.COBportR.FormattingEnabled = true;
            this.COBportR.Location = new System.Drawing.Point(167, 76);
            this.COBportR.Name = "COBportR";
            this.COBportR.Size = new System.Drawing.Size(121, 21);
            this.COBportR.TabIndex = 22;
            this.COBportR.Text = "NONE";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Nova Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(149, 20);
            this.label4.TabIndex = 21;
            this.label4.Text = "COM PORT RECEIVER";
            // 
            // CBOondD
            // 
            this.CBOondD.AutoSize = true;
            this.CBOondD.Font = new System.Drawing.Font("Arial Nova Cond", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBOondD.Location = new System.Drawing.Point(15, 294);
            this.CBOondD.Name = "CBOondD";
            this.CBOondD.Size = new System.Drawing.Size(87, 20);
            this.CBOondD.TabIndex = 23;
            this.CBOondD.Text = "One Device";
            this.CBOondD.UseVisualStyleBackColor = true;
            this.CBOondD.CheckedChanged += new System.EventHandler(this.CBOondD_CheckedChanged);
            // 
            // CBOtwoD
            // 
            this.CBOtwoD.AutoSize = true;
            this.CBOtwoD.Font = new System.Drawing.Font("Arial Nova Cond", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBOtwoD.Location = new System.Drawing.Point(124, 294);
            this.CBOtwoD.Name = "CBOtwoD";
            this.CBOtwoD.Size = new System.Drawing.Size(94, 20);
            this.CBOtwoD.TabIndex = 24;
            this.CBOtwoD.Text = "Two Devices";
            this.CBOtwoD.UseVisualStyleBackColor = true;
            this.CBOtwoD.CheckedChanged += new System.EventHandler(this.CBOtwoD_CheckedChanged);
            // 
            // HexBox
            // 
            this.HexBox.AutoSize = true;
            this.HexBox.Font = new System.Drawing.Font("Arial Nova Cond", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HexBox.Location = new System.Drawing.Point(684, 216);
            this.HexBox.Name = "HexBox";
            this.HexBox.Size = new System.Drawing.Size(49, 20);
            this.HexBox.TabIndex = 25;
            this.HexBox.Text = "HEX";
            this.HexBox.UseVisualStyleBackColor = true;
            this.HexBox.CheckedChanged += new System.EventHandler(this.HexBox_CheckedChanged);
            // 
            // CharBox
            // 
            this.CharBox.AutoSize = true;
            this.CharBox.Font = new System.Drawing.Font("Arial Nova Cond", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CharBox.Location = new System.Drawing.Point(683, 242);
            this.CharBox.Name = "CharBox";
            this.CharBox.Size = new System.Drawing.Size(56, 20);
            this.CharBox.TabIndex = 26;
            this.CharBox.Text = "CHAR";
            this.CharBox.UseVisualStyleBackColor = true;
            this.CharBox.CheckedChanged += new System.EventHandler(this.CharBox_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.CharBox);
            this.Controls.Add(this.HexBox);
            this.Controls.Add(this.CBOtwoD);
            this.Controls.Add(this.CBOondD);
            this.Controls.Add(this.COBportR);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.CobPbits);
            this.Controls.Add(this.Pbits);
            this.Controls.Add(this.CobSbits);
            this.Controls.Add(this.Sbits);
            this.Controls.Add(this.CobDbits);
            this.Controls.Add(this.Dbits);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.COBbaud);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SendUart);
            this.Controls.Add(this.ReceiveTxt);
            this.Controls.Add(this.SendTxt);
            this.Controls.Add(this.COBport);
            this.Controls.Add(this.COM);
            this.Controls.Add(this.CloseUart);
            this.Controls.Add(this.openUart);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "C# UART - BY Dan Iton";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button openUart;
        private System.Windows.Forms.Button CloseUart;
        private System.Windows.Forms.Label COM;
        private System.Windows.Forms.ComboBox COBport;
        private System.Windows.Forms.TextBox SendTxt;
        private System.Windows.Forms.TextBox ReceiveTxt;
        private System.Windows.Forms.Button SendUart;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox COBbaud;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label Dbits;
        private System.Windows.Forms.ComboBox CobDbits;
        private System.Windows.Forms.ComboBox CobSbits;
        private System.Windows.Forms.Label Sbits;
        private System.Windows.Forms.Label Pbits;
        private System.Windows.Forms.ComboBox CobPbits;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.IO.Ports.SerialPort serialPort2;
        private System.Windows.Forms.ComboBox COBportR;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox CBOondD;
        private System.Windows.Forms.CheckBox CBOtwoD;
        private System.Windows.Forms.CheckBox HexBox;
        private System.Windows.Forms.CheckBox CharBox;
    }
}

